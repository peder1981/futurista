
---

## 📄 LICENSE (modelo MIT)

```txt
MIT License

Copyright (c) 2025 Peder

Permission is hereby granted, free of charge, to any person obtaining a copy...

